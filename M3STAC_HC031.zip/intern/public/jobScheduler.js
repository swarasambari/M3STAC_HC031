const cron = require('node-cron');
const mongoose = require('mongoose');
const Job = require('../models/article'); // Adjust the path to your Job model

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/jobsinterns', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('Error connecting to MongoDB:', err));

// Cron job: Runs every day at midnight
cron.schedule('0 0 * * *', async () => {
  try {
    // Calculate the date 30 days ago from now
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Delete jobs older than 30 days
    const result = await Job.deleteMany({ createdAt: { $lt: thirtyDaysAgo } });
    console.log(`Deleted ${result.deletedCount} jobs older than 30 days`);
  } catch (err) {
    console.error('Error deleting old jobs:', err);
  }
});

console.log('Scheduled job deletion task is set.');
