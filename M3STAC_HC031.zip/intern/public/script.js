document.addEventListener('DOMContentLoaded', function() {
    const apiKey = 'pub_538219c64198a2cbac921d09aab73515a6ea7'; // Replace with your API key
    const apiUrl = `https://newsdata.io/api/1/news?apikey=${apiKey}&country=in&language=en&category=technology`; // Corrected URL

    async function fetchNews() {
        console.log('Fetching news...');
        try {
            const response = await fetch(apiUrl);
            console.log('Response received:', response);
            if (!response.ok) {
                console.error(`HTTP Error! Status: ${response.status}`);
                return;
            }
            const data = await response.json();
            console.log('Data received:', data); // Log data to see if articles are received
            displayNews(data.results); // Update to data.results based on Newsdata.io structure
        } catch (error) {
            console.error('Error fetching news:', error);
        }
    }

    function displayNews(articles) {
        const newsContainer = document.getElementById('news-container');
        newsContainer.innerHTML = ''; // Clear existing articles
        if (!articles || articles.length === 0) {
            newsContainer.innerHTML = '<p>No news articles available.</p>';
            return;
        }
        articles.forEach(article => {
            const articleElement = document.createElement('div');
            articleElement.className = 'article';
            articleElement.innerHTML = `
                <h2><a href="${article.link}" target="_blank">${article.title}</a></h2>
                <p>${article.description || 'No description available.'}</p>
            `;
            newsContainer.appendChild(articleElement);
        });
    }

    // Load news on page load
    fetchNews();

    // Load more functionality
    const loadMoreButton = document.getElementById('load-more');
    if (loadMoreButton) {
        loadMoreButton.addEventListener('click', fetchNews);
    } else {
        console.error('Load More button not found.');
    }
});
