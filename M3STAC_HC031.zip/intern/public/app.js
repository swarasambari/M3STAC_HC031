document.addEventListener('DOMContentLoaded', () => {
  const apiUrl = 'https://api.adzuna.com/v1/api/jobs/in/search/1';
  const apiId = '15c83181';
  const apiKey = '347032fd15be6ab9284d6970371ee48f';
  
  const apiJobsContainer = document.getElementById('api-jobs-container');
  
  // Define technical job keywords
  const techJobKeywords = [
    'Technical', 'Tech', 'Technology', 'IT', 'Engineering', 'Developer', 'Engineer', 
    'Programmer', 'Software', 'Coding', 'Programming', 'Technical Support', 'Help Desk', 'Team Lead', 'Senior Manager',
    'Software Engineer', 'Software Developer', 'Backend Developer', 'Frontend Developer',
    'Full Stack Developer', 'Mobile Developer', 'Web Developer', 'Application Developer',
    'Java Developer', 'Python Developer', 'JavaScript Developer', 'C++ Developer',
    'Ruby Developer', 'PHP Developer', 'React Developer', 'Angular Developer', 'Vue.js Developer',
    'Swift Developer', 'Kotlin Developer', '.NET Developer',
    'Data Scientist', 'Data Analyst', 'Data Engineer', 'Business Intelligence', 'Data Analysis',
    'Data Science', 'Big Data', 'Machine Learning Engineer', 'AI Engineer', 'Data Architect',
    'Business Analyst', 'Statistical Analyst', 'Predictive Analytics', 'Data Visualization',
    'Data Modeling', 'Quantitative Analyst', 'Operations Analyst', 'Data Management', 'Data Consultant',
    'ETL Developer', 'Data Warehouse Architect', 'Data Integration Specialist', 'Analytics Consultant',
    'Data Operations Manager', 'Data Quality Analyst', 'Business Data Analyst', 'Data Strategy', 'Data Governance',
    'Cloud Engineer', 'Cloud Architect', 'DevOps Engineer', 'AWS Engineer', 'Azure Engineer',
    'GCP Engineer', 'DevOps Specialist', 'CI/CD Engineer', 'Infrastructure Engineer',
    'Kubernetes Engineer', 'Docker Engineer', 'Terraform Engineer', 'Site Reliability Engineer',
    'Cloud Solutions Architect', 'Platform Engineer', 'Cloud Consultant', 'Cloud Operations',
    'Cybersecurity Analyst', 'Information Security Engineer', 'Security Engineer', 'Network Security',
    'Penetration Tester', 'Ethical Hacker', 'Security Analyst', 'Security Operations',
    'Incident Response', 'Forensic Analyst', 'Security Consultant', 'Threat Analyst', 'Security Architect',
    'Security Administrator', 'Vulnerability Analyst', 'Risk Assessment Analyst',
    'QA Engineer', 'Quality Assurance Engineer', 'Test Engineer', 'Automation Tester', 
    'Manual Tester', 'Performance Tester', 'Load Tester', 'API Tester',
    'Test Automation Engineer', 'Selenium Tester', 'Mobile App Tester', 'Software Tester', 'QA Analyst',
    'Systems Engineer', 'Hardware Engineer', 'Embedded Systems Engineer', 'Firmware Engineer',
    'IoT Engineer', 'Network Engineer', 'Systems Administrator', 'Hardware Developer',
    'Electronics Engineer', 'Circuit Design Engineer', 'FPGA Engineer', 'ASIC Engineer',
    'PCB Design Engineer', 'Embedded Firmware Engineer', 'Hardware Test Engineer',
    'Electromechanical Engineer', 'Power Electronics Engineer', 'Systems Integration Engineer',
    'Microcontroller Engineer', 'Embedded Software Engineer',
    'AI Specialist', 'AI Researcher', 'Robotics Engineer', 'Machine Learning Scientist',
    'Robotics Software Engineer', 'Automation Engineer', 'Product Manager',
    'Computer Vision Engineer', 'Natural Language Processing Engineer', 'Reinforcement Learning Engineer',
    'AI Research Scientist', 'Robotic Process Automation Engineer',
    'Game Developer', 'Game Designer', 'Unity Developer', 'Unreal Engine Developer', 
    'Gameplay Programmer', '3D Game Developer', 'VR Game Developer', 'AR Game Developer',
    'Game Engine Programmer', 'Game Artist', 'Game Animator',
    'Blockchain Developer', 'Cryptography Engineer', 'Smart Contract Developer', 
    'Solidity Developer', 'Blockchain Engineer', 'Web3 Developer',
    'Decentralized Application Developer', 'Ethereum Developer', 'Blockchain Architect',
    'Cryptocurrency Analyst', 'Blockchain Consultant',
    'AR Developer', 'VR Developer', 'Quantum Computing Engineer', 'Edge Computing Engineer',
    'Bioinformatics Developer', 'Drone Software Engineer', '5G Engineer', 'FinTech Developer',
    'Smart City Engineer', 'Wearable Technology Engineer', 'Space Technology Engineer',
    'Digital Twin Engineer', 'IoT Architect', 'Augmented Reality Engineer',
    'Technical Intern', 'Software Engineering Intern', 'Data Science Intern', 'Cloud Engineering Intern',
    'DevOps Intern', 'Cybersecurity Intern', 'QA Testing Intern', 'Freelance Developer',
    'Freelance Data Analyst', 'Freelance Data Scientist', 'Freelance Cloud Engineer',
    'Freelance Software Engineer', 'Freelance UX/UI Designer',
    'Network Administrator', 'Network Engineer', 'Infrastructure Engineer', 'Network Architect',
    'Systems Analyst', 'Network Consultant', 'Network Security Engineer', 'Telecommunications Engineer',
    'UX Designer', 'UI Designer', 'UX/UI Developer', 'User Experience Designer', 'User Interface Designer',
    'Interaction Designer', 'Product Designer', 'Web Designer', 'Visual Designer',
    'Linux Administrator', 'Linux Engineer', 'Unix Administrator', 'Unix Engineer',
    'Linux Systems Administrator', 'Unix Systems Administrator', 'Linux Support Engineer',
    'Linux DevOps Engineer', 'Unix DevOps Engineer', 'Linux Shell Scripting', 'Unix Shell Scripting',
    'Linux Systems Engineer', 'Unix Systems Engineer',
    'Machine Learning Engineer', 'ML Engineer', 'Deep Learning Engineer', 'AI Engineer', 
    'ML Research Scientist', 'ML Specialist', 'Machine Learning Researcher', 'ML Ops Engineer',
    'Data Scientist', 'AI Developer', 'ML Architect', 'Neural Network Engineer', 'Data Mining Engineer',
    'Predictive Modeling Analyst', 'Feature Engineer', 'Algorithm Developer', 'ML Consultant',
    'Database Administrator', 'Database Engineer', 'Database Developer', 'Oracle DBA', 'Oracle Developer',
    'MongoDB Developer', 'MongoDB Administrator', 'SQL Developer', 'SQL DBA', 'SQL Server Developer',
    'MySQL Developer', 'PostgreSQL Developer', 'Database Architect', 'NoSQL Developer', 'Database Consultant',
    'Database Analyst', 'Database Solutions Architect', 'Database Manager', 'SQL Analyst'
  ];
  
  async function fetchJobs() {
    const url = `${apiUrl}?app_id=${apiId}&app_key=${apiKey}`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        apiJobsContainer.innerHTML = ''; // Clear the container before adding jobs

        if (data.results && data.results.length) {
            // Filter jobs based on the expanded technical keywords
            const filteredJobs = data.results.filter(job =>
                techJobKeywords.some(keyword => job.title && job.title.toLowerCase().includes(keyword.toLowerCase()))
            );

            if (filteredJobs.length > 0) {
                filteredJobs.forEach(job => {
                    const jobElement = document.createElement('div');
                    jobElement.className = 'job api-job'; // Use the same 'job' class for styling
                    jobElement.dataset.title = job.title; // Set dataset for filtering
                    jobElement.dataset.description = job.description || 'No description available'; // Set dataset for filtering
                    jobElement.dataset.location = job.location ? job.location.display_name : 'Not available'; // Set dataset for filtering

                    jobElement.innerHTML = `
                        <h3 class="job-title">${job.title}</h3>
                        <p><strong class="company-location">Company:</strong> <span class="company">${job.company ? job.company.name : 'Not available'}</span></p>
                        <p><strong class="company-location">Location:</strong> <span class="location">${job.location ? job.location.display_name : 'Not available'}</span></p>
                        <p class="job-summary">${job.description || 'No description available'}</p>
                        <p><a href="${job.redirect_url}" target="_blank">Apply Now</a></p>
                    `;
                    apiJobsContainer.appendChild(jobElement);
                });
            } else {
                apiJobsContainer.innerHTML = '<p>No technical jobs found.</p>';
            }
        } else {
            apiJobsContainer.innerHTML = '<p>No jobs found.</p>';
        }
    } catch (error) {
        console.error('Error fetching jobs:', error);
        apiJobsContainer.innerHTML = '<p>Error fetching jobs. Please try again later.</p>';
    }
}

  fetchJobs();
});


// app.js

function resetFilters() {
  // Clear search input
  document.getElementById('job-search').value = '';

  // Reset filter dropdown to default
  document.getElementById('job-filter').value = 'default';

  // Call filterJobs to reapply filters with default settings
  filterJobs();
}

function filterJobs() {
  console.log("Invoked");
  const searchInput = document.getElementById('job-search').value.toLowerCase();
  const filterOption = document.getElementById('job-filter').value;

  // Filter and sort jobs for posted jobs
  filterAndSortJobs('posted-jobs-container', searchInput, filterOption);
  
  // Filter and sort jobs for API jobs
  filterAndSortJobs('api-jobs-container', searchInput, filterOption);
}

// document.getElementById('switch-role-link').addEventListener('click', function(event) {
//   event.preventDefault(); // Prevent the default behavior of link click (which is reloading the page)

//   axios.post('/switch-role')
//       .then(response => {
//           // Optionally show a message or handle UI updates here
//           window.location.reload(); // Reload the page after switching the role to reflect changes
//       })
//       .catch(error => {
//           console.error('Error switching role:', error);
//       });
// });



function filterAndSortJobs(containerId, searchInput, filterOption) {
  const container = document.getElementById(containerId);
  const jobs = container.querySelectorAll('.job');

  // Convert NodeList to Array for sorting
  const jobsArray = Array.from(jobs);

  // Filter jobs based on search
  jobsArray.forEach(job => {
    const title = job.dataset.title ? job.dataset.title.toLowerCase() : '';
    const description = job.dataset.description ? job.dataset.description.toLowerCase() : '';
    const location = job.dataset.location ? job.dataset.location.toLowerCase() : '';

    if (title.includes(searchInput) || description.includes(searchInput) || location.includes(searchInput)) {
      job.style.display = '';
    } else {
      job.style.display = 'none';
    }
  });

  document.querySelector('.profile-section > a').addEventListener('click', function(e) {
    e.preventDefault();
    const dropdown = document.querySelector('.profile-dropdown');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

document.addEventListener('click', function(e) {
    if (!document.querySelector('.profile-section').contains(e.target)) {
        document.querySelector('.profile-dropdown').style.display = 'none';
    }
});


  // Sort jobs based on filter option
  if (filterOption === 'date') {
    jobsArray.sort((a, b) => new Date(b.dataset.createdat) - new Date(a.dataset.createdat));
  } else if (filterOption === 'alphabetical') {
    jobsArray.sort((a, b) => a.dataset.title.localeCompare(b.dataset.title));
  } else if (filterOption === 'compensation-high') {
    jobsArray.sort((a, b) => {
      // Extract numerical values from compensation strings
      const aCompensation = a.dataset.compensation && a.dataset.compensation.split(' - ')[1] ? parseInt(a.dataset.compensation.split(' - ')[1].replace(/[^\d]/g, '')) : 0;
      const bCompensation = b.dataset.compensation && b.dataset.compensation.split(' - ')[1] ? parseInt(b.dataset.compensation.split(' - ')[1].replace(/[^\d]/g, '')) : 0;
      return bCompensation - aCompensation;
    });
  } else if (filterOption === 'compensation-low') {
    jobsArray.sort((a, b) => {
      // Extract numerical values from compensation strings
      const aCompensation = a.dataset.compensation && a.dataset.compensation.split(' - ')[1] ? parseInt(a.dataset.compensation.split(' - ')[1].replace(/[^\d]/g, '')) : 0;
      const bCompensation = b.dataset.compensation && b.dataset.compensation.split(' - ')[1] ? parseInt(b.dataset.compensation.split(' - ')[1].replace(/[^\d]/g, '')) : 0;
      return aCompensation - bCompensation;
    });
  }

  // Reorder the jobs in the DOM
  container.innerHTML = '';
  jobsArray.forEach(job => container.appendChild(job));
}
