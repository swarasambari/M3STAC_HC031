const mongoose = require('mongoose');

const applicantSchema = new mongoose.Schema({
    fullName: String,
    email: String,
    phone: String,
    jobTitle: String,
    experience: Number,
    skills: String,
    resume: String, // Path to uploaded resume
    jobId: mongoose.Schema.Types.ObjectId, // The job this application is for
}, { timestamps: true });

module.exports = mongoose.model('Applicant', applicantSchema);
