// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    googleId: {
        type: String,
        unique: false
    },
    mobile: {
        type: String,
        required: false // Optional for Google OAuth
    },
    password: {
        type: String,
        required: false // Optional for Google OAuth
    },
    role:{
        type: String,
        required: false // Optional for Google OAuth
    }
});

// Hash the password before saving the user
userSchema.pre('save', async function (next) {
    const user = this;
    
    // Only hash the password if it has been modified (or is new)
    if (user.isModified('password')) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
    }
    next();
});

// Method to compare the entered password with the hashed password
userSchema.methods.isValidPassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model('User', userSchema);
module.exports = User;
