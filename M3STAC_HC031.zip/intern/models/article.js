const mongoose = require('mongoose');

const articleSchema = new mongoose.Schema({
    title: String,
    summary: String,
    resp: String,
    exp: String,
    ts: String,
    ss: String,
    type: String,
    time: String,
    comp: String,
    ws: String,
    loc: String,
    ir: String,
    join: String,
    qual: String,
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // Link to user who posted
    applicantsCollection: String // Dynamic collection for applicants
}, { timestamps: true }); // Adds `createdAt` and `updatedAt` fields automatically




module.exports = mongoose.model('Article', articleSchema);
