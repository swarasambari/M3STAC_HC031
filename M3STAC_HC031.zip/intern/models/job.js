// job model
const mongoose = require('mongoose');

const JobSchema = new mongoose.Schema({
    title: String,
    summary: String,
    resp: String,
    exp: String,
    ts: String,
    ss: String,
    type: String,
    time: String,
    comp: String,
    ws: String,
    loc: String,
    ir: String,
    join: String,
    qual: String,
    createdBy: mongoose.Schema.Types.ObjectId, // Reference to the user who created the job
    applicantsCollection: String // The name of the dynamically created collection
}, { timestamps: true });

module.exports = mongoose.model('Job', JobSchema);

