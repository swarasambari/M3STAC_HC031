const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
    title: String,
    description: String,
    instructor: String,
    duration: String,
    link: String,
    fees: String,
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' } // Link to the user who posted the course
}, { timestamps: true }); // Adds `createdAt` and `updatedAt` fields automatically

module.exports = mongoose.model('Course', courseSchema);
