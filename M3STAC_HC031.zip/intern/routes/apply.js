const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Article = require('../models/article'); // Your job model
const PersonalInfo = require('../models/personal'); // Import the personal info model


// Route to render the application form
router.get('/:id', async (req, res) => {
    console.log(`Requested ID: ${req.params.id}`); // Debugging line
    const jobId = req.params.id;
    try {
        const job = await Article.findById(jobId).exec();
        console.log(`Job found: ${job}`); // Debugging line
        if (job) {
            // Fetch personal info of the user
            const personalInfo = await PersonalInfo.findOne({ createdBy: req.user._id });

            res.render('apply', { 
                job, 
                personalInfo: personalInfo || { name: '', email: '', mobile: '' } // Pass personal info to the template
            });
        } else {
            res.status(404).send('Job not found');
        }
    } catch (error) {
        console.error('Error fetching job:', error);
        res.status(500).send('Server error');
    }
});

module.exports = router;