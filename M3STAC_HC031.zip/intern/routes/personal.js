const express = require('express');
const router = express.Router();
const PersonalInfo = require('../models/personal'); // Adjust the path as necessary

// Route to render personal information page
// Route to render personal information page
router.get('/', async (req, res) => {
    try {
        const personalInfo = await PersonalInfo.findOne({ createdBy: req.user._id });
        res.render('personal-info', {
            personalInfo: personalInfo || { name: '', email: '', mobile: '', isEditable: true }, // Ensure fields are populated
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
        res.render('/login');
    }
});


// Route to handle personal info submission
router.post('/update-personal-info', async (req, res) => {
  const { name, email, mobile } = req.body;
  const userId = req.user._id; // Assuming user ID is stored in req.user

  const existingInfo = await PersonalInfo.findOne({ createdBy: userId });

  if (existingInfo) {
    return res.status(400).send('You can only fill this form once. To edit, please use the edit option.');
  }

  const personalInfo = new PersonalInfo({ name, email, mobile, createdBy: userId });
  await personalInfo.save();

  res.redirect('/personal-info'); // Redirect after successful save
});

// Route to handle editing personal info
router.post('/edit-personal-info', async (req, res) => {
    try {
      const { name, email, mobile } = req.body;
      const userId = req.user._id; // Assuming user ID is stored in the session or JWT
  
      // Find and update the personal info in one step
      const personalInfo = await PersonalInfo.findOneAndUpdate(
        { createdBy: userId }, // Find the document by user ID
        { name, email, mobile }, // Update with new values
        { new: true } // Return the updated document
      );
  
      if (!personalInfo) {
        console.log('No personal information found for user:', userId); // Log if no info found
        return res.status(404).send('No personal information found.');
      }
  
      console.log('Updated personal information:', personalInfo); // Log the updated info
      res.redirect('/personal-info'); // Redirect after successful edit
    } catch (error) {
      console.error('Error updating information:', error); // Log error details
      res.status(500).send('Server Error');
    }
  });
  
  
  

module.exports = router;
