// Assuming you're using Express.js

const Job = require('../models/article'); // Model for your Job postings
const Skill = require('../models/skill'); // Model for user skills

// Function to fetch user skills and jobs, then filter based on matching skills
async function getSkillBasedJobs(req, res) {
    try {
        const userId = req.user._id; // Assuming you have user in request object
        const userSkills = await Skill.find({ userId }).lean();
        const userSkillNames = userSkills.map(skill => skill.name.toLowerCase());

        // Fetch jobs from your database
        const postedJobs = await Job.find({}).lean();

        // Example API call to fetch other jobs
        const otherJobsResponse = await axios.get('https://api.example.com/jobs');
        const apiJobs = otherJobsResponse.data.jobs;

        // Filter jobs based on user skills
        const filterJobsBySkills = (jobs) => {
            return jobs.filter(job => {
                const jobKeywords = (job.title + ' ' + job.description).toLowerCase();
                return userSkillNames.some(skill => jobKeywords.includes(skill));
            });
        };

        const filteredPostedJobs = filterJobsBySkills(postedJobs);
        const filteredApiJobs = filterJobsBySkills(apiJobs);

        res.render('index', {
            articles: filteredPostedJobs,
            apiJobs: filteredApiJobs,
            userSkills: userSkillNames // Optional: to show user skills on the page
        });

    } catch (error) {
        console.error('Error fetching jobs:', error);
        res.status(500).send('Server Error');
    }
}

module.exports = {
    getSkillBasedJobs
};
