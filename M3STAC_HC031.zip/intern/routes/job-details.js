// Inside your Express route file (e.g., articleRoutes.js)
const express = require('express');
const router = express.Router();
const Job = require('../models/article'); // Assuming this is your job model
const mongoose = require('mongoose');

// Route to render job details page
router.get('/:id', async (req, res) => {
    console.log(`Requested ID: ${req.params.id}`);
    try {
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const articles = await Job.find({});
        console.log(articles);
        const jobs = await Job.find({ createdBy: userId });
        const job = await Job.findById(req.params.id); // Fetch the job by ID
        if (!job) {
            return res.status(404).send('Job not found');
        }
        res.render('job-details', { job, articles, jobs, user: req.user  }); // Pass the job data to the view
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});




module.exports = router;
