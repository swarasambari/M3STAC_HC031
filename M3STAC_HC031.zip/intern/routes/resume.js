const express = require('express');
const router = express.Router();
const multer = require('multer');
const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

// Set up multer for file uploads
const upload = multer({ dest: 'uploads/' });

router.post('/get-resume-score', upload.single('resume'), async (req, res) => {
    const filePath = req.file.path;

    try {
        // Read the file and send it to the ATS checker API
        const formData = new FormData();
        formData.append('resume', fs.createReadStream(filePath));

        const response = await axios.post('https://api.example.com/ats-check', formData, {
            headers: {
                'Authorization': `Bearer YOUR_API_KEY`,
                ...formData.getHeaders(),
            }
        });

        // Process the response from the ATS checker API
        const score = response.data.score; // Adjust according to the API response structure
        const feedback = response.data.feedback; // Adjust according to the API response structure

        res.json({ score, feedback });

    } catch (error) {
        console.error('Error checking resume:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    } finally {
        // Clean up uploaded file
        fs.unlink(filePath, (err) => {
            if (err) console.error('Error deleting file:', err);
        });
    }
});

module.exports = router;
