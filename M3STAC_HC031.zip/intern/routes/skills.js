const express = require('express');
const router = express.Router();
const Skill = require('../models/skill'); // Import Skill model
const ensureAuthenticated = require('../middleware/auth'); // Middleware for user authentication

// Get all skills for the authenticated user
router.get('/', ensureAuthenticated, async (req, res) => {
    try {
        const skills = await Skill.find({ createdBy: req.user._id });
        res.render('skills', { skills });
    } catch (error) {
        console.error('Error fetching skills:', error);
        res.status(500).send('Server error');
    }
});

// Add a new skill
router.post('/add', ensureAuthenticated, async (req, res) => {
    const { name } = req.body;

    if (!name) {
        return res.status(400).json({ message: 'Skill name is required' });
    }

    try {
        const newSkill = new Skill({
            name,
            createdBy: req.user._id
        });

        await newSkill.save();
        res.status(201).json(newSkill);
    } catch (error) {
        console.error('Error adding skill:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
