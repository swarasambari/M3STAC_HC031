const express = require('express');
const router = express.Router();
const mongoose = require('mongoose'); 
const Article = require('../models/article'); // Your job model

// Route to render the application form
router.get('/:id', async (req, res) => {
    console.log(`Requested ID: ${req.params.id}`); // Debugging line
    const jobId = req.params.id;
    try {
        const job = await Article.findById(jobId).exec();
        console.log(`Job found: ${job}`); // Debugging line
        if (job) {
            res.render('apply', { job });
        } else {
            res.status(404).send('Job not found');
        }
    } catch (error) {
        console.error('Error fetching job:', error);
        res.status(500).send('Server error');
    }
});


// Route to handle form submission
router.post('/:id', async (req, res) => {
    console.log('POST /apply/:id route hit');
    console.log('Request Body:', req.body); // Add this line to debug

    const jobId = req.params.id;
    const { fullName, email, phone, jobTitle, experience, skills, resume } = req.body;

    // Check if the values are being correctly extracted
    console.log('Extracted Values:', { fullName, email, phone, jobTitle, experience, skills, resume });

    try {
        const job = await Article.findById(jobId);
        if (!job) {
            return res.status(404).send('Job not found');
        }

        const collectionName = `job_${jobId}_applicants`;
        console.log(`Saving applicant to collection: ${collectionName}`);

        let dynamicApplicantModel;
        if (mongoose.models[collectionName]) {
            dynamicApplicantModel = mongoose.models[collectionName];
        } else {
            const applicantSchema = new mongoose.Schema({
                fullName: { type: String, required: true },
                email: { type: String, required: true },
                phone: { type: String, required: true },
                jobTitle: { type: String, required: true },
                experience: { type: Number, required: true },
                skills: { type: String, required: true },
                resume: {type: String, required: true},
                appliedAt: { type: Date, default: Date.now }
            });

            dynamicApplicantModel = mongoose.model(collectionName, applicantSchema, collectionName);
        }

        const applicant = new dynamicApplicantModel({
            fullName,
            email,
            phone,
            jobTitle,
            experience,
            skills,
            resume
        });

        await applicant.save();
        console.log('Applicant saved successfully');

        res.redirect('/thank-you');
    } catch (error) {
        console.error('Error processing application:', error);
        res.status(500).send('Server error');
    }
});



module.exports = router;
