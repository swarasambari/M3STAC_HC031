const express = require('express');
const router = express.Router();
const Article = require('../models/article');
const mongoose = require('mongoose');
const ensureAuthenticated = require('../middleware/auth');

// Route to view applicants for all jobs posted by the user
router.get('/view-applicants', ensureAuthenticated, async (req, res) => {
    try {
        console.log("Fetching jobs posted by the user:", req.user._id);

        // Find all jobs posted by the logged-in user
        const articles = await Article.find({ createdBy: req.user._id });
        console.log("Jobs found:", articles.length);
        const jobId = req.params.id;
        const jobsWithApplicantCounts = await Promise.all(
            articles.map(async (job) => {
                console.log(`Processing job: ${job.title} (ID: ${jobId})`);

                // Dynamically generate the applicants collection name using the job ID
                const collectionName = `job_${jobId}_applicants`;
                console.log(`Generated collection name: ${collectionName}`);

                // Check if the model for this collection already exists
                let ApplicantModel;
                if (mongoose.models[collectionName]) {
                    console.log(`Model for collection ${collectionName} already exists`);
                    ApplicantModel = mongoose.models[collectionName];
                } else {
                    console.log(`Creating model for collection: ${collectionName}`);
                    ApplicantModel = mongoose.model(
                        collectionName,
                        new mongoose.Schema({}, { strict: false }),
                        collectionName
                    );
                }

                try {
                    // Count the number of documents (applicants) in the collection
                    const applicantCount = await ApplicantModel.countDocuments();
                    console.log(`Applicant count for job ${job.title} (ID: ${job._id}): ${applicantCount}`);
                    
                    // Return the job title and its applicant count
                    return {
                        title: job.title,
                        applicantCount,
                    };
                } catch (error) {
                    console.error(`Error counting documents in collection ${collectionName}`, error);
                    return { title: job.title, applicantCount: 0 };
                }
            })
        );

        console.log("Final job list with applicant counts:", jobsWithApplicantCounts);
        
        // Render the view with the jobs and applicant counts
        res.render('view-applicants', { jobsWithApplicantCounts });
    } catch (err) {
        console.error("Error fetching jobs or applicants:", err);
        res.status(500).send('Server error');
    }
});

module.exports = router;
