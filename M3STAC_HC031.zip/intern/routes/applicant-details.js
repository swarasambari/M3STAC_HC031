const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const getApplicantModel = (jobId) => {
    const collectionName = `job_${jobId}_applicants`;
    const modelName = collectionName; // Use collectionName as the model name

    // Check if the model is already defined
    if (mongoose.models[modelName]) {
        return mongoose.models[modelName];
    }

// Function to get the model for applicants dynamically based on jobId
// const getApplicantModel = (jobId) => {
//     const collectionName = `job_${jobId}_applicants`; // Collection name is dynamic
//     const applicantSchema = new mongoose.Schema({
//         fullName: String,
//         email: String,
//         phone: String,
//         jobTitle: String,
//         experience: Number,
//         skills: String,
//         resume: String,
//         jobId: mongoose.Schema.Types.ObjectId,
//         appliedAt: { type: Date, default: Date.now }
//     });
    
//     // Return the model for the dynamic collection
//     return mongoose.model(collectionName, applicantSchema, collectionName);
// };

const applicantSchema = new mongoose.Schema({
    fullName: String,
    email: String,
    phone: String,
    jobTitle: String,
    experience: Number,
    skills: String,
    resume: String,
    jobId: mongoose.Schema.Types.ObjectId,
    appliedAt: { type: Date, default: Date.now }
});
return mongoose.model(modelName, applicantSchema, collectionName);
};

// Route to get applicant details
router.get('/:jobId/applicants/:applicantId', async (req, res) => {
    const { jobId, applicantId } = req.params; // Extract jobId and applicantId from URL

    try {
        // Get the model for the correct job collection
        const Applicant = getApplicantModel(jobId);

        // Find the applicant in that collection by applicantId
        const applicant = await Applicant.findById(applicantId);

        if (!applicant) {
            return res.status(404).render('404', { message: 'Applicant not found' });
        }

        // Render the applicant details page
        res.render('applicant-details', { applicant });
    } catch (error) {
        console.error(error);
        res.status(500).render('error', { message: 'Server Error' });
    }
});


module.exports = router;
