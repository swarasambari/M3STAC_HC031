const express = require('express');
const Article = require('../models/article');
const mongoose = require('mongoose');
const Router = express.Router();
const Course = require('../models/course'); // Assuming the Course model is in the models folder
const ensureAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/login');

};

// Route to render the course posting form
Router.get('/new', ensureAuthenticated, async(req, res) => {
    const userId = new mongoose.Types.ObjectId(req.user._id); // Convert to ObjectId
    const articles = await Article.find({});
    const jobs = await Article.find({ createdBy: userId }); 

    res.render('course/new', { user: req.user, articles, jobs }); // Assuming you have a form template at views/course/new.ejs
});

// Route to handle the form submission
Router.post('/', ensureAuthenticated, (req, res) => {
    const { title, description, instructor, duration, link, fees } = req.body;

    const course = new Course({
        title,
        description,
        instructor,
        duration,
        link,
        fees,
        createdBy: req.user._id
    });

    course.save()
        .then(() => {
            res.redirect('/coursesDisplay');
        })
        .catch((err) => {
            console.error(err);
            res.redirect('/course/new');
        });
});

//Route to display all courses
Router.get('/', ensureAuthenticated, async (req, res) => {
    try {
        const courses = await Course.find({});
        res.render('coursesDisplay', { courses, user: req.user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});






module.exports = Router;
