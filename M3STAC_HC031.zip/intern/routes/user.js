const express = require('express');
const Router = express.Router();
const Article = require('../models/article'); // Assuming you have Article model
const mongoose = require('mongoose'); // For dynamic collection names


const ensureAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/login');
};


// New job posting route
Router.get('/new', ensureAuthenticated, async (req, res) => {
    try {
        console.log('User object:', req.user); // Debugging: Check if user is defined
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const articles = await Article.find({ createdBy: userId });
        console.log('Jobs:', articles); // Debugging: Check if jobs array has data
        res.render('article/new', { articles, user: req.user }); // Passing user object
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

Router.post('/', ensureAuthenticated, (req, res) => {
    const { title, summary, resp, exp, ts, ss, type, time, comp, ws, loc, ir, join, qual } = req.body;

    // Create a dynamic collection name for applicants
    const applicantsCollectionName = `applicants_${new mongoose.Types.ObjectId()}`;

    const article = new Article({
        title,
        summary,
        resp,
        exp,
        ts,
        ss,
        type,
        time,
        comp,
        ws,
        loc,
        ir,
        join,
        qual,
        createdBy: req.user._id, // Ensure req.user is defined here
        applicantsCollection: applicantsCollectionName
    });

    article.save()
        .then(() => {
            res.redirect('/index');
        })
        .catch((err) => {
            console.error(err);
            res.redirect('/article/new');
        });
});

module.exports = Router;