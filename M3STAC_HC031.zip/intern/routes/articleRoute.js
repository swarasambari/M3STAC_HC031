const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Job = require('../models/job');

// router.get('/new', ensureAuthenticated, async (req, res) => {
//     try {
//         const userId = new mongoose.Types.ObjectId(req.user._id); // Convert to ObjectId
//         const articles = await Article.find({});
//         const user = req.user;
//         const jobs = await Article.find({ createdBy: userId });
//         res.render('article/new', { user, jobs });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Server error');
//     }
// });


router.post('/article', async (req, res) => {
    const jobData = req.body;

    // Create a new job
    const job = new Job(jobData);

    // Generate a dynamic applicants collection name for this job
    const dynamicCollectionName = `applicants_${job._id}`;
    job.applicantsCollection = dynamicCollectionName;

    await job.save();

    res.redirect('/index');
});

module.exports = router;
