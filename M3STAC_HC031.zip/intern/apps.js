const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('passport');
const expressLayouts = require('express-ejs-layouts');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const LocalStrategy = require('passport-local').Strategy;
const dotenv = require('dotenv');
const User = require('./models/User');
const Article = require('./models/article');
const Course= require('./models/course');
const flash = require('connect-flash');
const Job = require('./models/job');
const articleRoutes = require('./routes/user');
const applicantRoutes = require('./routes/applicants');
const applyRoutes = require('./routes/apply');
const jobDetailsRoutes = require('./routes/job-details');
const courseRoutes = require('./routes/courses');
const personalRoute = require('./routes/personal');


// const articleRoute = require('./routes/articleRoutes');
const applicantDetailsRoutes = require('./routes/applicant-details');
dotenv.config();

// Initialize express app
const app = express();
const port = process.env.PORT || 8082;
const bcrypt = require('bcrypt');

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/jobsinterns', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('Error connecting to MongoDB:', err));

// Session management
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: false, // Change this to false
    cookie: { secure: false }  // Set secure: true in production with HTTPS
}));

// Use flash for storing messages
app.use(flash());

// Set up a middleware to pass flash messages to every view
app.use((req, res, next) => {
    res.locals.error_msg = req.flash('error');
    next();
});

// Passport initialization
app.use(passport.initialize());
app.use(passport.session());

// EJS setup
app.set('view engine', 'ejs');
app.use(expressLayouts);

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Google Authentication Routes
app.get('/auth/google', passport.authenticate('google', {
    scope: ['profile', 'email']
}));

app.get('/auth/google/callback', passport.authenticate('google', {
    failureRedirect: '/login',
    failureFlash: true
}), (req, res) => {
    res.redirect('/index');
});



// Use route files
app.use('/article', articleRoutes);


// app.use('/applicants', applicantRoutes);

app.use('/personal-info', personalRoute);
app.use('/job-details', jobDetailsRoutes);
app.use('/applicant-details', applicantDetailsRoutes);
// Static files
app.use(express.static('public'));

//  Make flash messages accessible in views
// app.use((req, res, next) => {
//     res.locals.success_msg = req.flash('success_msg');
//     res.locals.error_msg = req.flash('error_msg');
//     res.locals.error = req.flash('error');
//     next();
// });



// Passport Local Strategy
passport.use(new LocalStrategy({
    usernameField: 'username',
    passwordField: 'password'
}, async (username, password, done) => {
    try {
        const user = await User.findOne({ username });
        if (!user) {
            return done(null, false, { message: 'Username not found' });
        }
        const isMatch = await user.isValidPassword(password);
        if (!isMatch) {
            return done(null, false, { message: 'Incorrect password' });
        }
        return done(null, user);
    } catch (err) {
        return done(err);
    }
}));

passport.use(new GoogleStrategy({
    clientID: '453287884724-c23bjg7enor29d6oqsrtga3k6j2fs791.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: "http://localhost:8082/auth/google/callback"
}, async (accessToken, refreshToken, profile, done) => {
    try {
        let user = await User.findOne({ email: profile.emails[0].value });
        if (!user) {
            user = new User({
                username: profile.displayName,
                email: profile.emails[0].value,
                googleId: profile.id
            });
            await user.save();
        }
        return done(null, user);
    } catch (err) {
        return done(err);
    }
}));

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id);
        done(null, user);
    } catch (err) {
        done(err, null);
    }
});

// Middleware to ensure authentication
const ensureAuthenticated = (req, res, next) => {
    console.log("Checking authentication"); // Debugging line
    if (req.isAuthenticated()) {
        console.log("User authenticated:", req.user); // Debugging line
        return next();
    } else {
        console.log("User not authenticated"); // Debugging line
        res.redirect('/login');
    }
};
app.use('/apply', applyRoutes);

//applicants route
app.use('/job/:id/applicants', ensureAuthenticated, applicantRoutes);
app.use('/course', ensureAuthenticated, courseRoutes);

// app.use('/course', courseRouter);

// Routes

require('./public/jobScheduler.js');
app.get('/', (req, res) => {
    // Check if error_msg exists in the session
    const error_msg = req.session.error_msg || null;

    // Clear the error_msg from the session after it is retrieved
    req.session.error_msg = null;

    // Render the login page with the error message
    res.render('login', { error_msg });
});

app.get('/login', (req, res) => {
    // Check if error_msg exists in the session
    const error_msg = req.session.error_msg || null;

    // Clear the error_msg from the session after it is retrieved
    req.session.error_msg = null;

    // Render the login page with the error message
    res.render('login', { error_msg });
});

app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return next(err);
        }
        if (!user) {
            // Set error message in session
            req.session.error_msg = 'Invalid username or password';
            return res.redirect('/'); // Redirect to the login page
        }
        req.logIn(user, (err) => {
            if (err) {
                return next(err);
            }
            return res.redirect('/index'); // Redirect on successful login
        });
    })(req, res, next);
});





app.get('/register', (req, res) => res.render('register', { error: null }));

// app.post('/register', async (req, res) => {
//     const { username, email, password, phone } = req.body;
//     try {
//         const userExists = await User.findOne({ $or: [{ username }, { email }] });
//         if (userExists) {
//             return res.render('register', { error: 'Username or Email already exists' });
//         }
//         const newUser = new User({
//             username,
//             email,
//             password,
//             mobile: phone,
//         });
//         await newUser.save();
//         res.redirect('/login');
//     } catch (error) {
//         console.error('Error registering user:', error);
//         res.render('register', { error: 'Error registering user' });
//     }
// });

app.post('/register', async (req, res) => {
    const { username, email, password, phone, role } = req.body;
    try {
        const userExists = await User.findOne({ $or: [{ username }, { email }] });
        if (userExists) {
            return res.render('register', { error: 'Username or Email already exists' });
        }
        const newUser = new User({
            username,
            email,
            password,
            mobile: phone,
            role
        });
        await newUser.save();
        res.redirect('/login');
    } catch (error) {
        console.error('Error registering user:', error);
        res.render('register', { error: 'Error registering user' });
    }
});


// app.post('/switch-role', (req, res) => {
//     const user = req.user; // Assuming user is stored in req.user
    
//     // Toggle role between 'recruiter' and 'applier'
//     if (user.role === 'recruiter') {
//       user.role = 'applier';
//     } else {
//       user.role = 'recruiter';
//     }
  
//     // Save the updated role in session or database
//     req.session.user = user; // If using session
//     res.redirect('/index'); // Redirect to the homepage or another page
//   });


// app.post('/update-personal-info', async (req, res) => {
//     const { name, email, mobile } = req.body;
//     const userId = req.user._id; // Assuming user ID is stored in req.user
  
//     const existingInfo = await PersonalInfo.findOne({ createdBy: userId });
  
//     if (existingInfo) {
//       return res.status(400).send('You can only fill this form once. To edit, please use the edit option.');
//     }
  
//     const personalInfo = new PersonalInfo({ name, email, mobile, createdBy: userId });
//     await personalInfo.save();
  
//     res.redirect('/somewhere'); // Redirect after successful save
//   });

//   app.post('/edit-personal-info', async (req, res) => {
//     const { name, email, mobile } = req.body;
//     const userId = req.user._id;
  
//     const personalInfo = await PersonalInfo.findOne({ createdBy: userId });
  
//     if (!personalInfo) {
//       return res.status(404).send('No personal information found.');
//     }
  
//     personalInfo.name = name;
//     personalInfo.email = email;
//     personalInfo.mobile = mobile;
//     personalInfo.isEditable = false; // Set to false after editing
//     await personalInfo.save();
  
//     res.redirect('/somewhere'); // Redirect after successful edit
//   });


//   app.get('/apply/:jobId', async (req, res) => {
//     const jobId = req.params.jobId;
//     const job = await Job.findById(jobId);
//     const personalInfo = await PersonalInfo.findOne({ createdBy: req.user._id });
  
//     res.render('apply-now', {
//       job,
//       personalInfo // Pass personalInfo to the template
//     });
//   });
    
app.get('/logout', (req, res) => {
    req.logout(() => res.redirect('/login'));
});
app.get('/home', ensureAuthenticated, (req, res) => res.render('home', { user: req.user }));



app.get('/index', ensureAuthenticated, async (req, res) => {
    try {
        const userId = new mongoose.Types.ObjectId(req.user._id); // Convert to ObjectId
        const articles = await Article.find({});
        const jobs = await Article.find({ createdBy: userId }); // Fetch jobs created by the logged-in user
        res.render('index', { articles, jobs, user: req.user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/coursesDisplay', ensureAuthenticated, async (req, res) => {
    try {
        const userId = new mongoose.Types.ObjectId(req.user._id); // Convert to ObjectId
        const articles = await Article.find({});
        const courses= await Course.find({});
        const jobs = await Article.find({ createdBy: userId }); // Fetch jobs created by the logged-in user
        res.render('coursesDisplay', { articles, jobs, user: req.user, courses });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

// app.get('/personal-info', ensureAuthenticated, async (req, res) => {
//     try {
//         const userId = new mongoose.Types.ObjectId(req.user._id); // Convert to ObjectId
//         const articles = await Article.find({});
//         const courses= await Course.find({});
//         const jobs = await Article.find({ createdBy: userId }); // Fetch jobs created by the logged-in user
//         res.render('personal-info', { articles, jobs, user: req.user, courses });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Server error');
//     }
// });

app.get('/about', ensureAuthenticated, async (req, res) => {
    try {
        // Optionally, fetch any additional data if needed
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const user = req.user;
        const jobs = await Article.find({ createdBy: userId }); 
        res.render('about', { jobs, user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});


// app.get('/switch-role', (req, res) => {
//     const user = req.user; // Assuming the user is stored in req.user
  
//     // Toggle the role between 'recruiter' and 'applier'
//     user.role = user.role === 'recruiter' ? 'applier' : 'recruiter';
  
//     // Save the updated role in the session or database
//     req.session.user = user; // If using session
    
//     res.redirect('/index'); // Redirect back to the homepage or another appropriate page
//   });
// app.get('/courses', ensureAuthenticated, async (req, res) => {
//     try {
//         // Optionally, fetch any additional data if needed
//         const userId = new mongoose.Types.ObjectId(req.user._id);
//         const user = req.user;
//         const articles = await Article.find({ createdBy: userId }); 
//         const courses = getCourses();
//         res.render('courses', { courses, articles, user });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Server error');
//     }
// });

app.get('/promote-course', ensureAuthenticated, async (req, res) => {
    try {
        // Optionally, fetch any additional data if needed
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const user = req.user;
        const articles = await Article.find({ createdBy: userId }); 
        res.render('promote-course', { articles, user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});


app.get('/score-checker', ensureAuthenticated, async (req, res) => {
    try {
        // Optionally, fetch any additional data if needed
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const user = req.user;
        const jobs = await Article.find({ createdBy: userId }); 
        res.render('score-checker', { jobs, user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});


app.get('/tech-news', ensureAuthenticated, async (req, res) => {
    try {
        // Optionally, fetch any additional data if needed
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const user = req.user;
        const articles = await Article.find({ createdBy: userId }); 
        res.render('tech-news', { articles, user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});


app.get('/contact', ensureAuthenticated, async (req, res) => {
    try {
        // Optionally, fetch any additional data if needed
        const userId = new mongoose.Types.ObjectId(req.user._id);
        const user = req.user;
        const jobs = await Article.find({ createdBy: userId });
        res.render('contact', { jobs, user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/set-password', (req, res) => {
    if (!req.user) {
        return res.redirect('/login');
    }
    res.render('set-password');
});
app.post('/set-password', async (req, res) => {
    const { password } = req.body;
    const user = req.user;
    if (!user) {
        return res.redirect('/login');
    }
    try {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(password, salt);
        await user.save();
        res.redirect('/index');
    } catch (error) {
        res.redirect('/set-password');
    }
});

const skillsRoutes = require('./routes/skills');
app.use('/skills', skillsRoutes);

app.get('/thank-you', (req, res) => res.render('thank-you'));
app.get('/job/:id', async (req, res) => {
    const jobId = req.params.id;
    try {
        const job = await Job.findById(jobId);
        if (job) {
            res.render('info', { job });
        } else {
            res.status(404).send('Job not found');
        }
    } catch (error) {
        console.error('Error fetching job:', error);
        res.status(500).send('Server error');
    }
});
app.get('/view-applicants', ensureAuthenticated, async (req, res) => {
    console.log("View Applicants route hit"); // Debugging line
    try {
        // Debugging: Log the user ID of the authenticated user
        console.log('Authenticated user ID:', req.user._id);
        
        // Fetch all jobs created by the current user
        const jobs = await Article.find({ createdBy: req.user._id });
        console.log('Fetched jobs:', jobs); // Debugging: Log the jobs fetched
        
        // Fetch applicants for each job
        const jobsWithApplicants = await Promise.all(jobs.map(async (job) => {
            const collectionName = `job_${job._id}_applicants`;
            console.log('Fetching applicants from collection:', collectionName); // Debugging: Log the collection name
            const applicants = await mongoose.connection.collection(collectionName).find().toArray();
            console.log(`Applicants for job ${job.title}:`, applicants); // Debugging: Log the applicants for each job
            return { job, applicants };
        }));
        
        // Debugging: Log the jobs with applicants before rendering
        console.log('Jobs with applicants:', jobsWithApplicants);
        
        // Pass the jobs with their applicants and user information to the template
        res.render('view-applicants', { jobsWithApplicants, user: req.user });
    } catch (error) {
        console.error('Error fetching applicants:', error);
        res.status(500).send('Server error');
    }
});


app.delete('/delete-job/:id', ensureAuthenticated, async (req, res) => {
    try {
      const jobId = req.params.id;
      // Find and delete the job from the Article collection
      const deletedJob = await Article.findByIdAndDelete(jobId);
  
      if (!deletedJob) {
        return res.status(404).json({ success: false, message: 'Job not found.' });
      }
  
      res.json({ success: true, message: 'Job deleted successfully.' });
    } catch (err) {
      console.error('Error deleting job:', err);
      res.status(500).json({ success: false, message: 'Server error.' });
    }
  });
  
// app.get('/article', ensureAuthenticated, async (req, res) => {
//     try {
//         const userId = new mongoose.Types.ObjectId(req.user._id); // Convert to ObjectId
//         const jobs = await Article.find({ createdBy: userId }); // Fetch jobs created by the logged-in user
//         res.render('article/new', { user: req.user, jobs });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Server error');
//     }
// });


// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
